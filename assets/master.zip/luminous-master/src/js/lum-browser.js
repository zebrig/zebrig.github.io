// This file is used for the standalone browser build

import Luminous from "./Luminous";
import LuminousGallery from "./LuminousGallery";

window["LuminousGallery"] = LuminousGallery;
window["Luminous"] = Luminous;
